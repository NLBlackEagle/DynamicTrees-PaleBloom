package nlblackeagle.dynamictreespalebloom.proxy;

import com.ferreusveritas.dynamictrees.api.TreeHelper;
import com.ferreusveritas.dynamictrees.api.client.ModelHelper;
import com.ferreusveritas.dynamictrees.blocks.BlockDynamicLeaves;
import com.ferreusveritas.dynamictrees.blocks.LeavesPaging;

import nlblackeagle.dynamictreespalebloom.DynamicTreesPaleBloom;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import nlblackeagle.dynamictreespalebloom.ModContent;
import nlblackeagle.dynamictreespalebloom.event.PaleLungHudHandler;
import nlblackeagle.dynamictreespalebloom.event.PaleLungParticleHandler;
import nlblackeagle.dynamictreespalebloom.event.PaleLungSeedBombSoundHandler;

@SideOnly(Side.CLIENT)
public class ClientProxy extends CommonProxy {

    @Override
    public void preInit() {
        super.preInit();
    }

    @Override
    public void init() {
        super.init();
        registerColorHandlers();
        MinecraftForge.EVENT_BUS.register(new PaleLungHudHandler());
        MinecraftForge.EVENT_BUS.register(new PaleLungParticleHandler());
        MinecraftForge.EVENT_BUS.register(new PaleLungSeedBombSoundHandler());
    }

    @Override
    public void postInit() {
        super.postInit();
    }

    public void registerColorHandlers() {

        for (BlockDynamicLeaves leaves : LeavesPaging.getLeavesMapForModId(DynamicTreesPaleBloom.MODID).values()) {
            ModelHelper.regColorHandler(leaves, (state, worldIn, pos, tintIndex) -> {
                Block block = state.getBlock();

                if (TreeHelper.isLeaves(block)) {
                    return ((BlockDynamicLeaves) block).getProperties(state).foliageColorMultiplier(state, worldIn, pos);
                }
                return 0x00FF00FF;
            });
        }
    }
}